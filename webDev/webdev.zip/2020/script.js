function alertUser() {
    let message = 'Δεν συμπληρώσατε τους κωδικούς';
    let code = document.getElementById('code').value;
    let password = document.getElementById('password').value;
    if(code && password) {
        message = 'Επιτυχής σύνδεση';
    }        
 }

function changeWindow(url) {
    window.location.href = url;
}

function Submit() {
    let username = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    if(username.length >= 8 && email.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
        document.getElementById('last-p').innerHTML = 'Επιτυχής Καταχώρηση';
    } else {
        document.getElementById('last-p').innerHTML = 'Ελλειπή Στοιχεία';
    }
}
