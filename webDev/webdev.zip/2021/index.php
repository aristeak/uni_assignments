<?php

    $servername = 'localhost';
    $username = 'root';
    $password = '';

    $conn = new mysqli($servername, $username, $password);

    if($conn->connect_error) {
        die("Connection failed ".$conn->connect_error);
    }

    // $db_query = "CREATE DATABASE ics21058";
    $db = "USE ics21058"; 
    $conn->query($db);

    // $table_query = "CREATE TABLE ics21058 (id INTEGER, name TEXT, website TEXT)";
    // $db_done = $conn->query($db_query) === TRUE;
    // $table_done = $conn->query($table_query) === TRUE;
    $table_done = TRUE;
    if($table_done) {
        echo '<p>All done</p><br>';
        echo '<a href="show.php">Εμφάνιση</a> <a href="set.php">Καταχώριση</a> <a href="pick.php">Διαλογή</a>';
    }

    $conn->close();
?>