<!DOCTYPE html>
<html>
    <head>
        <title>SET</title>
    </head>
    <body>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
            <label for="id">ID:</label>
            <input type="text" name="id">
            <label for="name">NAME:</label>
            <input type="text" name="name">
            <label for="website">WEBSITE:</label>
            <input type="text" name="website">
            <input type="submit" value="Submit">
        </form>

        <?php 

            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                $id = $_POST['id'];
                $name = $_POST['name'];
                $website = $_POST['website'];

                if(empty($name)) {
                    echo 'Name is required';
                } else {
                    $name = test_input($name);
                }

                if(empty($website)) {
                    echo 'Website is required';
                    $website = '';
                } else {
                    $website = test_input($website); 
                    if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website)) { 
                        echo "Invalid URL"; 
                        $website = '';
                    } 
                }
                
                if($name && $website) {
                    $servername = 'localhost';
                    $username = 'root';
                    $password = '';
    
                    $conn = new mysqli($servername, $username, $password);

                    if($conn->connect_error) {
                        die("Error connecting to".$conn->connect_error);
                    }
                    $conn->query("USE ics21058");
                    $conn->query("INSERT INTO ics21058 VALUES ($id, '$name', '$website')");

                    $conn->close();
                }
                

            }
            

            function test_input($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
        ?>
    </body>
</html>