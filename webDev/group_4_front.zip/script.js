function changeVertical() {
    let p = document.getElementById('paragraph');
    p.style.width = '200px';
    p.style.height = '300px';
}

function changeHorizontal() {
    let p = document.getElementById('paragraph');
    p.style.width = '300px';
    p.style.height = '200px';
}