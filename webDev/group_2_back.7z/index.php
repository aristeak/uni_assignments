<?php

    $servername = 'localhost';
    $username = 'root';
    $password = '';

    $conn = new mysqli($servername, $username, $password);

    if($conn->connect_error) {
        die("Connection failed ".$conn->connect_error);
    }

    $db_query = "CREATE DATABASE ics21058";
    $db_done = $conn->query($db_query) === TRUE;

    if($db_query) {
        echo "<p>Δημιουργήθηκε η βάση</p><br>";
    } else {
        echo "<p>Προέκυψε σφάλμα στην δημιουργία βάσης</p><br>";
    }
    $conn->close();

    $dbname = 'ics21058';
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    $table_query = "CREATE TABLE ics21058 (id int, name TEXT)";
    $table_done = $conn->query($table_query) === TRUE;
    
    if($table_done) {
        echo "<p>Δημιουργήθηκε ο πίνακας</p><br>";
    } else {
        echo "<p>Προέκυψε σφάλμα στην δημιουργία πίνακα</p><br>";
    }

    echo "<p><a href='view.php'>Εμφάνιση</a></p> <p><a href='insert.php'>Καταχώριση</a></p>";

    $conn->close();
?>