
<!DOCTYPE html>
<html>
    <head>
        <title>INSERT</title>
    </head>
    <body>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
            <label for="name">NAME:</label>
            <input type="text" name="name">
            <input type="submit" value="Submit">
        </form>

        <?php

            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                $name = $_POST['name'];

                if(empty($name)) {
                    echo 'Name is required';
                    $name = '';
                } else {
                    // $name = test_input($name);
                    if (!preg_match("/^[A-Za-z]+$/",$name)) {
                        echo "Invalid URL";
                        $name = '';
                    }
                }

                if($name) {
                    $servername = 'localhost';
                    $username = 'root';
                    $password = '';
                    $dbname = 'ics21058';
   
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    if($conn->connect_error) {
                        die("Error connecting to".$conn->connect_error);
                    }
                    // $conn->query("USE ics21058");
                    $conn->query("INSERT INTO ics21058 (name) VALUES ('$name')");

                    $conn->close();
                }
               

            }
           
            // function test_input($data) {
            //     $data = trim($data);
            //     $data = stripslashes($data);
            //     $data = htmlspecialchars($data);
            //     return $data;
            // }
        ?>
    </body>
</html>