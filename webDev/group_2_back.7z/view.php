<?php

    $servername = 'localhost';
    $username = 'root';
    $password = '';

    $conn = new mysqli($servername, $username, $password);

    if($conn->connect_error) {
        die("Error connecting to".$conn->connect_error);
    }
    $conn->query("USE ics21058");
    $result = $conn->query("SELECT * FROM ics21058");

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo " <br> id: " . $row["id"]. " - Name: " . $row["name"] . "<br>";
        }
    } else {
        echo "0 results";
    } 
       

    $conn->close();

?>