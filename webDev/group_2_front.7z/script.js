function AddDigit(element) {
    let digit = element.innerHTML;
    document.getElementById('result-p').innerHTML += digit;
}