<?php

    $servername = 'localhost';
    $username = 'root';
    $password = '';

    $conn = new mysqli($servername, $username, $password);

    if($conn->connect_error) {
        die("Connection failed ".$conn->connect_error);
    }

    $db_query = "CREATE DATABASE ics21167";
    $db_done = $conn->query($db_query) === TRUE;
    
    $db = "USE ics21167"; 
    $conn->query($db);

    $table_query = "CREATE TABLE ics21167 (name TEXT, email TEXT)";
    $table_done = $conn->query($table_query) === TRUE;

    if($table_done) {
        echo '<p>Δημιουργήθηκε η βάση και ο πίνακας</p><br>';
        echo '<a href="showall.php">Παρουσίαση</a> <a href="into.php">Εισαγωγή</a>';
    }

    $conn->close();
?>