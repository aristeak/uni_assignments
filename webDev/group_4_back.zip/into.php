<!DOCTYPE html>
<html>
    <head>
    </head>
    <body>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
            <label for="name">NAME:</label>
            <input type="text" name="name">
            <label for="email">EMAIL:</label>
            <input type="text" name="email">
            <input type="submit" value="Submit">
        </form>

        <?php 

            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                $name = $_POST['name'];
                $email = $_POST['email'];

                if (!preg_match('/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/',$email)) { 
                    echo "Invalid URL"; 
                    $email = '';
                } 
                
                if($email) {
                    $servername = 'localhost';
                    $username = 'root';
                    $password = '';
    
                    $conn = new mysqli($servername, $username, $password);

                    if($conn->connect_error) {
                        die("Error connecting to".$conn->connect_error);
                    }
                    $conn->query("USE ics21167");
                    $conn->query("INSERT INTO ics21167 VALUES ('$name', '$email')");

                    $conn->close();
                }
            }
        ?>
    </body>
</html>