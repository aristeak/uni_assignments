<?php

    $servername = 'localhost';
    $username = 'root';
    $password = '';

    $conn = new mysqli($servername, $username, $password);

    if($conn->connect_error) {
        die("Error connecting to".$conn->connect_error);
    }
    $conn->query("USE ics21167");
    $result = $conn->query("SELECT * FROM ics21167");

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo " <br> Name: " . $row["name"]. " - Email: " . $row["email"] . "<br>";
        }
    } else {
        echo "0 results";
    } 
       

    $conn->close();

?>