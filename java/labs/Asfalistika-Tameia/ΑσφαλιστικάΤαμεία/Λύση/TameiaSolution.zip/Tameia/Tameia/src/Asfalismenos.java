
public abstract class Asfalismenos {
	
	private String name;
	private String AFM;
	protected double pososto;
	
	public String getName() {
		return name;
	}
	
	public Asfalismenos(String aName, String aAFM, double aPososto) {
		name = aName;
		AFM = aAFM;
		pososto = aPososto;
	}
	
	public abstract double calcIncome();
}
