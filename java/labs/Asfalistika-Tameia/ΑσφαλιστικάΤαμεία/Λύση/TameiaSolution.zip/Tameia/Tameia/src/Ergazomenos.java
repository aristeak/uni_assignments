
public class Ergazomenos extends Asfalismenos {
	
	double monthIncome;
	int children;
	
	public Ergazomenos(String aName, String aAFM, double aPososto, double income, int noChildren) {
		super(aName, aAFM, aPososto);
		monthIncome = income;
		children = noChildren;
	}
	
	public double calcIncome() {
		return (monthIncome*(1-pososto)+children*100);
	}
}
