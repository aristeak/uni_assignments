
public class Syntaxiouhos extends Asfalismenos {
	
	private double syntaxi;
	
	public Syntaxiouhos(String aName, String aAFM, double aPososto, double income) {
		super(aName, aAFM, aPososto);
		syntaxi = income;
	}
	
	public double calcIncome() {
		return syntaxi*(1-pososto);
	}

}
