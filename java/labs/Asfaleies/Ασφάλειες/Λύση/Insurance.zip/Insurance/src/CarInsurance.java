
public class CarInsurance extends Insurance {
	
	private int displacement;
	
	public CarInsurance(String aName, int aDuration, int aDisplacement) {
		super(aName, aDuration);
		displacement = aDisplacement;
	}
	
	public double calculateCharge() {
		return displacement * duration / 60;
	}

}
