
public class HouseInsurance extends Insurance {
	
	private int squareMeters;
	
	public HouseInsurance(String aName, int aDuration, int aSquareMeters) {
		super(aName, aDuration);
		squareMeters = aSquareMeters;
	}
	
	public double calculateCharge() {
		return squareMeters * duration / 10;
	}

}
