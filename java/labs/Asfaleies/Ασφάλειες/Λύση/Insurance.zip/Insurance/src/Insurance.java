
public abstract class Insurance {
	
	private String name;
	protected int duration;
	
	public Insurance(String aName, int aDuration) {
		name = aName;
		duration = aDuration;
	}
	
	public String getName() {
		return name;
	}
	
	public abstract double calculateCharge();

}
