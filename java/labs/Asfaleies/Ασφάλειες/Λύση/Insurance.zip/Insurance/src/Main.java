import java.util.ArrayList;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		ArrayList<Insurance> insurances = new ArrayList<Insurance>();
		
		InputFrame inputFrame = new InputFrame(insurances);
		ResultsFrame resultsFrame = new ResultsFrame(insurances);
		

	}

}
