import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ResultsFrame extends JFrame {
	
	private JList listView;
	private JPanel panel;
	private JButton refreshButton;
	private JButton calcButton;
	private JTextField chargeField;
	private ArrayList<Insurance> insurances;
	private DefaultListModel model;
	
	public ResultsFrame(ArrayList<Insurance> insurances) {
		
		this.insurances = insurances;
		
		listView = new JList();
		panel = new JPanel();
		refreshButton = new JButton("Ananewsh");
		calcButton = new JButton("Ypologismos Xrewshs");
		chargeField = new JTextField("chargeField");
		
		model = new DefaultListModel();
		
		model.addElement("Dummy Name 1");
		model.addElement("Dummy Name 2");
		model.addElement("Dummy Name 3");
		
		listView.setModel(model);
		
		panel.add(listView);
		panel.add(refreshButton);
		panel.add(calcButton);
		panel.add(chargeField);
		
		ButtonListener listener = new ButtonListener();
		refreshButton.addActionListener(listener);
		calcButton.addActionListener(listener);
		
		this.setContentPane(panel);
		
		this.setVisible(true);
		this.setSize(200, 300);
		this.setLocation(300, 0);
		this.setTitle("Results");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			if(e.getSource().equals(refreshButton)) {
				model.clear();
				for(Insurance i : insurances) {
					model.addElement(i.getName());
				}
			}
			else {
				String selectedName = (String)listView.getSelectedValue();
				for(Insurance i : insurances) {
					if(i.getName().equals(selectedName)) {
						double charge = i.calculateCharge();
						String chargeText = Double.toString(charge);
						chargeField.setText(chargeText);
					}
				}
			}
			
		}
	}

}
